<?php $__env->startSection('title','| Sell or Buy'); ?>


<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="responsive-tabs dashboard-tabs">
            <div class="tab-content">
                <div class="tab-pane active" id="buy">
                    <div class="row">
                        <div class="col-sm-8 col-sm-offset-2 page-content">
                            <div class="widget sidebar-widget white-container contact-form-widget">

                                <?php echo $__env->make('partials._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                <h5 class="widget-title">POST REQUEST</h5>

                                <div class="widget-content">
                                    <p>Item: <?php echo e($post->itemname); ?></p>
                                    <p>Item: <?php echo e($post->brand); ?></p>
                                    <p>Item: <?php echo e($post->description); ?></p>
                                    <p>Item: <?php echo e($post->location); ?></p>
                                    <p>Item: <?php echo e($post->email); ?></p>
                                    <p>Item: <?php echo e($post->item); ?></p>
                                    <p>Item: <?php echo e($post->item); ?></p>

                                    <p><?php echo e(Html::submit('Mark Solved',['class' => 'btn btn-info btn-block'],[$post->id])); ?></p>


                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- end .tabe pane -->


            </div> <!-- end .tab-content -->
        </div> <!-- end .responsive-tabs.dashboard-tabs -->

    </div> <!-- end .page-content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>