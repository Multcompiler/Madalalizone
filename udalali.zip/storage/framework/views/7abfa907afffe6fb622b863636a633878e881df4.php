<?php if(session('success')): ?>
    <div class="alert alert-info" role="alert">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if($errors->has()): ?>
    <div class="alert alert-danger" role="alert">
        <strong>Errors: </strong>
        <ul>
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>