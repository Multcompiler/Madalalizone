<?php $__env->startSection('title','| Login'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="responsive-tabs dashboard-tabs">
            <div class="col-sm-6 col-sm-offset-3 page-content" style="padding-top: 60px;padding-bottom: 180px;">

                <?php echo $__env->make('partials._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="widget sidebar-widget white-container contact-form-widget">
                    <h5 class="widget-title text-center">ADMIN LOGIN</h5>

                    <div class="widget-content">

                        <?php echo Form::open(['class' => 'mt30','data-parsley-validate' => '']); ?>

                        <div class="form-group">
                            <?php echo e(Form::email('email', null, ['placeholder' => 'Email Address','class' => 'form-control','required' => ''])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::password('password', ['placeholder' => 'Password','class' => 'form-control','required' => ''])); ?>

                        </div>

                        <?php echo e(Form::button('<i class="fa fa-lock"></i> Login', ['type' => 'submit', 'class' => 'btn btn-block btn-default'] )); ?>

                        <?php echo Form::close(); ?>


                        <div class="form-group" style="padding-top: 20px;">
                            <a href="<?php echo e(url('/')); ?>"><i class="fa fa-long-arrow-left"></i> Home</a>
                        </div>

                    </div>
                </div>
            </div> <!-- end .responsive-tabs.dashboard-tabs -->
        </div>
    </div> <!-- end .page-content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>