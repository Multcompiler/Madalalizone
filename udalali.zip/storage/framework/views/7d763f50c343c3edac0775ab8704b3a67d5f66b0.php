<!-- Scripts -->
<?php echo e(Html::script('js/jquery-3.1.1.min.js')); ?>

<?php echo e(Html::script('js/bootstrap.js')); ?>

<?php echo e(Html::script('js/jquery.ba-outside-events.min.js')); ?>

<?php echo e(Html::script('js/jquery.responsive-tabs.js')); ?>

<?php echo e(Html::script('js/jquery.flexslider-min.js')); ?>

<?php echo e(Html::script('js/jquery.fitvids.js')); ?>

<?php echo e(Html::script('js/jquery-ui-1.10.4.custom.min.js')); ?>

<?php echo e(Html::script('js/jquery.inview.min.js')); ?>

<?php echo e(Html::script('js/jquery-ui-1.10.4.custom.min.js')); ?>

<?php echo e(Html::script('js/owl.carousel.min.js')); ?>

<?php echo e(Html::script('js/scripts.js')); ?>

<?php echo e(Html::script('js/parsley.min.js')); ?>