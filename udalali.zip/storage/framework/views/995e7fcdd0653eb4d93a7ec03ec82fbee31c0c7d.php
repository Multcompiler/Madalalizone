<?php $__env->startSection('title','| Sell or Buy'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="responsive-tabs dashboard-tabs">
            <div class="tab-content">
                <div class="tab-pane active" id="buy">
                    <div class="row">
                        <div class="col-sm-8 col-sm-offset-2 page-content">
                            <div class="widget sidebar-widget white-container contact-form-widget">

                                <?php echo $__env->make('partials._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                <h5 class="widget-title">POST REQUEST</h5>

                                <div class="widget-content">
                                    <p>Item Name: <?php echo e($post->itemname); ?></p>
                                    <p>Item Brand: <?php echo e($post->brand); ?></p>
                                    <p>Item Description: <?php echo e($post->description); ?></p>
                                    <p>Amount: <?php echo e($post->offeramount); ?></p>
                                    <p>Location: <?php echo e($post->location); ?></p>
                                    <p>Phone: <?php echo e($post->phone); ?></p>
                                    <p>Posted At: <?php echo e(date('M j, Y',strtotime($post->created_at))); ?></p>
                                    <p>
                                        <?php echo e(($post->status)); ?>

                                    </p>

                                    <a href="tel:<?php echo e($post->phone); ?>" class="text-center btn btn-block btn-default" style="margin-top: 10px;"><i
                                                    class="fa fa-phone"></i> Contact Customer</a>
                                    <a href="<?php echo e(route('admin.buy.edit',$post->id)); ?>"
                                       class="text-center btn btn-block btn-default top_space">Mark As Solved</a>


                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- end .tabe pane -->


            </div> <!-- end .tab-content -->
        </div> <!-- end .responsive-tabs.dashboard-tabs -->

    </div> <!-- end .page-content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>