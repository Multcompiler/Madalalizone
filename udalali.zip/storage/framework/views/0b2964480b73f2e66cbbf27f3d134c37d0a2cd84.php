<!doctype html>
<html lang="en">

<head>
    <?php echo $__env->make('partials._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('partials._styles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body>
<div id="main-wrapper" class="our-agents-content">


    <header id="header">
        <div class="header-top-bar">

            <div class="header-notification-bar">
                <?php echo $__env->make('partials._navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

        </div>


    </header>

   <?php echo $__env->yieldContent('innerlinks'); ?>

    <div id="page-content" class="candidate-profile client-bg-color">
        <div class="container">
           <?php echo $__env->yieldContent('content'); ?>
        </div> <!-- end .container -->
    </div>

    <footer id="footer">
        <?php echo $__env->make('partials._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </footer>

</div>

<?php echo $__env->make('partials._scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>

</html>
