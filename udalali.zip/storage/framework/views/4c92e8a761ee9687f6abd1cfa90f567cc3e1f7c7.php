<?php $__env->startSection('title','| Sell or Buy'); ?>

<?php $__env->startSection('innerlinks'); ?>
    <div class="header-page-title clearfix">
        <div class="title-overlay"></div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="responsive-tabs dashboard-tabs">

            <ul class="nav nav-tabs">
                <li class="active"><a href="#buy">Buy</a></li>
                <li><a href="#sell">Sell</a></li>
            </ul>

            <div class="tab-content">
                <div class="tab-pane active" id="buy">
                    <div class="row">
                        <div class="col-sm-8 col-sm-offset-2 page-content">
                            <div class="widget sidebar-widget white-container contact-form-widget">

                                <?php echo $__env->make('partials._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                <h5 class="widget-title">ALL BUY REQUEST</h5>

                                <div class="widget-content">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>

                                            <th>#</th>
                                            <th>Item</th>
                                            <th>Brand</th>
                                            <th>Offer</th>
                                            <th>location</th>
                                            <th>Phone</th>
                                            <th></th>

                                            </thead>
                                            <tbody>

                                            <?php foreach($buy_post as $buy): ?>
                                                <tr>
                                                    <td><?php echo e($buy->id); ?></td>
                                                    <td><?php echo e($buy->itemname); ?></td>
                                                    <td><?php echo e($buy->brand); ?></td>
                                                    <td><?php echo e($buy->offeramount); ?></td>
                                                    <td><?php echo e($buy->location); ?></td>
                                                    <td><?php echo e($buy->phone); ?></td>
                                                    <td>
                                                     <a href="<?php echo e(url("/admin/$buy->categoryid/$buy->id")); ?>" class="btn btn-primary">View</a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>

                                            </tbody>
                                        </table>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- end .tabe pane -->

                <div class="tab-pane" id="sell">
                    <div class="row">
                        <div class="col-sm-8 col-sm-offset-2 page-content">
                            <div class="widget sidebar-widget white-container contact-form-widget">
                                <h5 class="widget-title">ALL SELL REQUEST</h5>

                                <div class="widget-content">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>

                                            <th>#</th>
                                            <th>Item</th>
                                            <th>Brand</th>
                                            <th>Offer</th>
                                            <th>location</th>
                                            <th>Phone</th>
                                            <th></th>

                                            </thead>
                                            <tbody>

                                            <?php foreach($sell_post as $sell): ?>
                                                <tr>
                                                    <td><?php echo e($sell->id); ?></td>
                                                    <td><?php echo e($sell->itemname); ?></td>
                                                    <td><?php echo e($sell->brand); ?></td>
                                                    <td><?php echo e($sell->amount); ?></td>
                                                    <td><?php echo e($sell->location); ?></td>
                                                    <td><?php echo e($sell->phone); ?></td>
                                                    <td>
                                                        <?php echo e(url("/admin/$sell->categoryid/$sell->id")); ?>


                                                       </td>
                                                </tr>
                                            <?php endforeach; ?>

                                            </tbody>
                                        </table>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- end .tabe pane -->


            </div> <!-- end .tab-content -->
        </div> <!-- end .responsive-tabs.dashboard-tabs -->

    </div> <!-- end .page-content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>