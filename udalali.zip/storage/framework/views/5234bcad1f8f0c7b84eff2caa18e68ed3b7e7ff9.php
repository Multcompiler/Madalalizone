<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600" rel="stylesheet">

<?php echo e(Html::style('css/bootstrap.css')); ?>

<?php echo e(Html::style('css/font-awesome.min.css')); ?>

<?php echo e(Html::style('css/jquery.tagsinput.css')); ?>

<?php echo e(Html::style('css/owl.carousel.css')); ?>

<?php echo e(Html::style('css/styles.css')); ?>

<?php echo e(Html::style('css/responsive.css')); ?>

<?php echo e(Html::style('css/parsley.css')); ?>



<!--[if IE 9]>
<?php echo e(Html::script('js/media.match.min.js')); ?>

<![endif]-->