<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600" rel="stylesheet">

{{Html::style('css/bootstrap.css')}}
{{Html::style('css/font-awesome.min.css')}}
{{Html::style('css/jquery.tagsinput.css')}}
{{Html::style('css/owl.carousel.css')}}
{{Html::style('css/styles.css')}}
{{Html::style('css/responsive.css')}}
{{Html::style('css/parsley.css')}}


<!--[if IE 9]>
{{Html::script('js/media.match.min.js')}}
<![endif]-->