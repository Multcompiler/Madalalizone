<div class="copyright">
    <div class="container">
        <p>Dalali Zone, 2018 &copy; All rights reserved.</p>

        <ul class="list-inline">
            <li><a href="http://www.facebook.com/godson.mandla" target="_blank"><i class="fa fa-facebook"></i></a></li>
            <li><a href="http://www.twitter.com/godsonmandla?lang=en" target="_blank"><i class="fa fa-twitter"></i></a></li>
            <li><a href="https://www.linkedin.com/in/godson-mandla-436288105/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
            <li><a  href="https://www.instagram.com/godson_mandla/" target="_blank"><i class=" fa fa-instagram"></i></a></li>
        </ul>
    </div>
</div>