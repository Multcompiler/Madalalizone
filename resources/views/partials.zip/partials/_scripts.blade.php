<!-- Scripts -->
{{Html::script('js/jquery-3.1.1.min.js')}}
{{Html::script('js/bootstrap.js')}}
{{Html::script('js/jquery.ba-outside-events.min.js')}}
{{Html::script('js/jquery.responsive-tabs.js')}}
{{Html::script('js/jquery.flexslider-min.js')}}
{{Html::script('js/jquery.fitvids.js')}}
{{Html::script('js/jquery-ui-1.10.4.custom.min.js')}}
{{Html::script('js/jquery.inview.min.js')}}
{{Html::script('js/jquery-ui-1.10.4.custom.min.js')}}
{{Html::script('js/owl.carousel.min.js')}}
{{Html::script('js/scripts.js')}}
{{Html::script('js/parsley.min.js')}}